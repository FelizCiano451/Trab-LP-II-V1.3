// Conteúdo de exemplo para README.md
