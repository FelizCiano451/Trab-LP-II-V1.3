// Conteúdo de exemplo para GerenciadorColecoesTest.java
