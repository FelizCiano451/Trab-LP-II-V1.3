// Conteúdo de exemplo para EntradaNaoEncontradaException.java
