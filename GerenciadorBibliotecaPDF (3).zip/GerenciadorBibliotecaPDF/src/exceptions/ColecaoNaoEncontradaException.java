// Conteúdo de exemplo para ColecaoNaoEncontradaException.java
