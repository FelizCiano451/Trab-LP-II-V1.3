// Conteúdo de exemplo para EntradaJaExisteException.java
