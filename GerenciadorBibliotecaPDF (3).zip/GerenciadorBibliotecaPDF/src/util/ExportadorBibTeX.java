// Conteúdo de exemplo para ExportadorBibTeX.java
