// Conteúdo de exemplo para CompactadorZip.java
