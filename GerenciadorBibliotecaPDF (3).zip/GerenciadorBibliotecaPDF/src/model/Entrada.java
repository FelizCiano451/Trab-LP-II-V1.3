// Conteúdo de exemplo para Entrada.java
