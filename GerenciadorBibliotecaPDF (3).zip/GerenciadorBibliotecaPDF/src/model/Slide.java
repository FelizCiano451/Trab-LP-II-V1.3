// Conteúdo de exemplo para Slide.java
