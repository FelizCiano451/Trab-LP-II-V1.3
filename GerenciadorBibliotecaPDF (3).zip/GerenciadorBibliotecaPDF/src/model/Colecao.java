// Conteúdo de exemplo para Colecao.java
