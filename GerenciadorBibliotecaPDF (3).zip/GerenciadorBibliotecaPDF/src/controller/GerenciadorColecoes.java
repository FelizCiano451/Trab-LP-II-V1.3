// Conteúdo de exemplo para GerenciadorColecoes.java
