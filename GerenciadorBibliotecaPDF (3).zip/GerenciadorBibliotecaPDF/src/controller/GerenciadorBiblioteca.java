// Conteúdo de exemplo para GerenciadorBiblioteca.java
